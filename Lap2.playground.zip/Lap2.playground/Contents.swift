import UIKit

// Task 1: Variable Practice

var score = Int()

    score += 10
print(score)



//Task 2: Control Flow

if score > 9 {
    
    print("Pass")
}else{
    
    print("Fail")
}



//Task 3: Loop Practice

var array : Array<String> = ["Ahmed","Khaled" , "Sami" , "Ali","Saleh"]

for i in array {
    
    print(i)
}




//Task 4: Working with Dictionaries

var fruit : [String:Int] = ["Banana": 4 , "Orange": 7 , "Pineapple": 2 ]


for i in fruit {
    
    print(i)
}




//Task 5: String Interpolation

let name = "diya"

print("hello \("")\(name)")
